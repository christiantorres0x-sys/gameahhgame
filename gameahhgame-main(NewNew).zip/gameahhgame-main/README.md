Added bridge puzzle with array
-bug with platform bumping into player, making player no-clip into terrain
+bridgepuzzle folder

Asset
+wood png (asset for planks)

Scenes
+platform
+sign.tscn
+bridge.tscn
+bridgepiece.tscn
+plank.tscn

Scripts
+sign.gd
+bridge.gd

Global Settings
-Gamestate.gd

